from django.urls import path
from . import views

app_name = 'App' # Namespacing

urlpatterns = [
    # path('', views.home_view, name='home'),
    
    # NEW PATH
    path('', views.hello_world, name='hello'),
]