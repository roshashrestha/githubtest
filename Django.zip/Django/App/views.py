from django.shortcuts import render

# Create your views here.

from django.http import HttpResponse # <--- Import this

# demo
def hello_world(request):
    # return HttpResponse("Hello World")
    print(request.method)
    return render(request, 'App/hello.html',{"name": "Rosha"})