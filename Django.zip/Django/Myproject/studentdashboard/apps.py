from django.apps import AppConfig


class StudentdashboardConfig(AppConfig):
    name = 'studentdashboard'
