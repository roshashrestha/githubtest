from django.urls import path
from . import views           #. =>init le garda jun file pani access garna milxa
from django.contrib.auth import views as auth_views # later for the login

app_name="studentdashboard"

urlpatterns=[
    path('',views.home,name="home"),
    path('dashboard/', views.student_dashboard, name='student_dashboard'),
    path('login/', auth_views.LoginView.as_view(template_name='login.html'), name='login'),
    path('student/add/', views.add_student, name='add_student'),
]