import json
from django.shortcuts import render, redirect
from django.http import HttpResponse
from .models import StudentProfile
from django.http import JsonResponse
from django.contrib.auth.decorators import login_required  # <--- THE FIX
from django.contrib import messages
from django.views.decorators.csrf import csrf_exempt

def home(request):
    return HttpResponse("<h1>Home page</h1>")


# @login_required
@csrf_exempt
def student_dashboard(request):
    # Fetch Data
    students = StudentProfile.objects.prefetch_related('grades').all()
    
    # 2. JSON API LOGIC: Check if requester wants JSON (API call)
    if request.headers.get('Accept') == 'application/json' or request.GET.get('format') == 'json':
        data = []
        for s in students:
            data.append({
                "roll": s.roll,
                "name": s.name,
                "program": s.program,
                "grades": list(s.grades.values('sem', 'gpa', 'status'))
            })
        # 3. STATUS CODE: Return 200 OK with JSON data
        return JsonResponse({"students": data}, status=200)

    # 4. HTML RESPONSE: Standard browser view
    context = {
        'students': students,
        'student_count': students.count(),
    }
    return render(request, 'dashboard.html', context, status=200)

# add students
@csrf_exempt
def add_student(request):
    if request.method == "POST":
        if request.content_type == 'application/json':
            try:
                data = json.loads(request.body)
            except json.JSONDecodeError:
                return JsonResponse({"error": "Invalid JSON"}, status=400)
        else:
            data = request.POST

        try:
            # 1. Create the Student
            student = StudentProfile.objects.create(
                name=data.get('name'),
                roll=data.get('roll'),
                program=data.get('program')
            )

            # 2. Create the Grade (Mandatory for your React structure)
            # This uses the gpa/sem logic from your Model
            student.grades.create(
                year=data.get('year') or "2024",
                sem=data.get('sem') or "1st",
                gpa=float(data.get('gpa')) if data.get('gpa') else 0.0
            )

            return JsonResponse({
                "message": "Student created successfully",
                "id": student.id
            }, status=201)

        except Exception as e:
            print(f"DATABASE ERROR: {e}") # Check your terminal for this!
            return JsonResponse({"error": str(e)}, status=500)

    return render(request, 'add_student.html')
    
    
    


